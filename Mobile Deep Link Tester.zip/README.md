
  # Mobile Deep Link Tester

  This is a code bundle for Mobile Deep Link Tester. The original project is available at https://www.figma.com/design/s6EiI9BR6xltkSGufqgToj/Mobile-Deep-Link-Tester.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  